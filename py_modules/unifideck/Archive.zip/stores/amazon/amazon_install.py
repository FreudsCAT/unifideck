"""Amazon Games installer — install / uninstall pipeline using nile.

OP-49d | py_modules/unifideck/stores/amazon/amazon_install.py

``AmazonInstaller`` orchestrates installs and uninstalls via the
``nile`` CLI. The install pipeline :

1. **preflight** — verify nile binary, resolve base path, build the
   install context;
2. **probe** — query nile for the game's manifest (size, fuel.json
   location, supported architectures);
3. **subprocess** — spawn nile with structured progress callbacks
   (parses nile's stdout for "downloaded X/Y bytes" lines);
4. **finalize** — parse the fuel.json from ``amazon_fuel.py``
   (OP-49f) to extract the launch executable, write the
   ``.unifideck-id`` marker, register with the install registry.

The uninstall path is symmetric : remove install dir, drop registry
entry, clean up shortcut + artwork cache.

Errors are wrapped into typed ``InstallResult`` envelopes ; partial
installs are cleaned up to avoid leaving orphaned files on disk.
"""

from __future__ import annotations
import asyncio
import logging
import os
import re
from collections.abc import Awaitable, Callable
from typing import Any, cast
from ...core.manifest import write_manifest
from ...core.types import (
    Events,
    InstallResult,
    Result,
)
from ...event_bus.event_bus import EventBus
from ..shared.cli_install_helpers import (
    drain_install_output,
    parse_progress_line,
    wait_with_timeout,
)
from . import amazon_fuel
from .amazon_library import AmazonLibraryReader

logger = logging.getLogger(__name__)
_PROGRESS_RE = re.compile(r"\[\s*(\d+)\s*%\s*\]")
ProgressCallback = Callable[[float], Awaitable[None]]


class AmazonInstaller:
    """Amazon installer."""

    def __init__(
        self,
        bus: EventBus,
        cli_path: str | None,
        library: AmazonLibraryReader,
        find_exe: Callable[[str, list[str] | None], str | None],
        default_install_root: str,
        install_timeout_seconds: int = 3600,
        uninstall_timeout_seconds: int = 120,
    ) -> None:
        """Initialize the instance."""
        self._bus = bus
        self._cli_path = cli_path
        self._library = library
        self._find_exe = find_exe
        self._default_install_root = os.path.expanduser(default_install_root)
        self._install_timeout = install_timeout_seconds
        self._uninstall_timeout = uninstall_timeout_seconds

    async def install_game(
        self,
        game_id: str,
        base_path: str | None = None,
        progress_cb: ProgressCallback | None = None,
    ) -> InstallResult:
        """Install game."""
        if not self._cli_path:
            return InstallResult(
                success=False,
                error="nile_not_found",
                store="amazon",
                game_id=game_id,
            )
        base = base_path or self._default_install_root
        try:
            os.makedirs(base, exist_ok=True)
        except OSError as e:
            return InstallResult(
                success=False,
                error=f"mkdir_failed: {e}",
                store="amazon",
                game_id=game_id,
            )
        await self._bus.emit(
            Events.DOWNLOAD_STARTED,
            store="amazon",
            game_id=game_id,
        )
        rc = await self._run_install(base, game_id, progress_cb)
        if rc != 0:
            await self._bus.emit(
                Events.DOWNLOAD_FAILED,
                store="amazon",
                game_id=game_id,
                error=f"nile_exit_{rc}",
            )
            return InstallResult(
                success=False,
                error=f"nile_exit_{rc}",
                store="amazon",
                game_id=game_id,
            )
        return await self._finalize_install(game_id, base)

    async def _finalize_install(self, game_id: str, base: str) -> InstallResult:
        """Finalize install."""
        install_path = await self._resolve_install_path(
            game_id,
            base,
        )
        exe = await self._resolve_executable(install_path, game_id)
        title = await self._resolve_title(game_id)
        if install_path:
            exe_relative = ""
            if exe:
                try:
                    exe_relative = os.path.relpath(
                        exe,
                        install_path,
                    )
                except ValueError:
                    pass
            await write_manifest(
                install_dir=install_path,
                store="amazon",
                store_id=game_id,
                title=title,
                executable_relative=exe_relative,
                platform="windows",
            )
        await self._bus.emit(
            Events.DOWNLOAD_COMPLETE,
            store="amazon",
            game_id=game_id,
            install_path=install_path,
        )
        return InstallResult(
            success=True,
            store="amazon",
            game_id=game_id,
            install_path=install_path or base,
        )

    async def _run_install(
        self,
        base: str,
        game_id: str,
        progress_cb: ProgressCallback | None,
    ) -> int:
        """Run install."""
        cmd = self._build_install_cmd(base, game_id)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        drain_exc: BaseException | None = None
        try:
            await self._drain_install_output(
                proc,
                game_id,
                progress_cb,
            )
        except BaseException as e:
            drain_exc = e
        rc = await self._wait_with_timeout(proc)
        if drain_exc is not None:
            raise drain_exc
        return rc

    def _build_install_cmd(self, base: str, game_id: str) -> list[str]:
        """Build install cmd."""
        if self._cli_path is None:
            raise RuntimeError(
                "nile CLI path is not set; cannot build install cmd",
            )
        return [
            self._cli_path,
            "install",
            game_id,
            "--base-path",
            base,
        ]

    async def _drain_install_output(
        self,
        proc: Any,
        game_id: str,
        progress_cb: ProgressCallback | None,
    ) -> None:
        """Drain install output."""
        await drain_install_output(
            proc,
            game_id,
            progress_cb,
            self._handle_install_line,
        )

    async def _wait_with_timeout(self, proc: Any) -> int:
        """Wait with timeout."""
        return await wait_with_timeout(
            proc,
            self._install_timeout,
            "[amazon_install]",
        )

    async def _handle_install_line(
        self,
        line: str,
        game_id: str,
        progress_cb: ProgressCallback | None,
    ) -> None:
        """Handle install line."""
        pct = parse_progress_line(line, _PROGRESS_RE)
        if pct is None:
            logger.debug("[nile install] %s", line)
            return
        if progress_cb is not None:
            try:
                await progress_cb(pct)
            except Exception as e:
                logger.debug(
                    "[amazon_install] progress_cb raised: %s",
                    e,
                )
        await self._bus.emit(
            Events.DOWNLOAD_PROGRESS,
            store="amazon",
            game_id=game_id,
            progress=pct,
        )

    async def _resolve_install_path(self, game_id: str, base: str) -> str | None:
        """Resolve install path."""
        installed = await self._library.read_installed_ids()
        info = installed.get(game_id)
        if info and info.get("path"):
            return cast("str | None", info["path"])
        default = os.path.join(base, game_id)
        if os.path.isdir(default):
            return default
        return None

    async def _resolve_executable(
        self,
        install_path: str | None,
        game_id: str,
    ) -> str | None:
        """Resolve executable."""
        if not install_path:
            return None
        from_fuel = amazon_fuel.find_exe_from_fuel(install_path)
        if from_fuel:
            return from_fuel
        return self._find_exe(install_path, [game_id])

    async def _resolve_title(self, game_id: str) -> str:
        """Resolve title."""
        owned = await self._library.read_owned_games()
        for game in owned:
            if game.store_game_id == game_id:
                return game.title
        return game_id

    async def uninstall_game(self, game_id: str) -> Result:
        """Uninstall game."""
        if not self._cli_path:
            return Result(
                success=False,
                error="nile_not_found",
            )
        proc = await asyncio.create_subprocess_exec(
            self._cli_path,
            "uninstall",
            game_id,
            "--yes",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=self._uninstall_timeout,
            )
        except TimeoutError:
            proc.kill()
            return Result(
                success=False,
                error="uninstall_timeout",
            )
        if proc.returncode != 0:
            err = stderr.decode(errors="ignore")[:200]
            return Result(
                success=False,
                error=f"uninstall_failed: {err}",
            )
        await self._bus.emit(
            Events.GAME_UNINSTALLED,
            store="amazon",
            game_id=game_id,
        )
        return Result(success=True)

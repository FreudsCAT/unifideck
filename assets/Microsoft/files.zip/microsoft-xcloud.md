# Microsoft / Xbox Cloud Gaming — Documentation technique

## Sommaire

- [Vue d'ensemble](#vue-densemble)
  - [Ce que ça apporte au plugin](#ce-que-ça-apporte-au-plugin)
- [Architecture](#architecture)
  - [Fichiers et responsabilités](#fichiers-et-responsabilités)
  - [Diagramme des modules](#diagramme-des-modules)
  - [Parcours utilisateur](#parcours-utilisateur-machine-détats)
- [Flux d'authentification](#flux-dauthentification)
  - [Séquence complète](#séquence-complète)
  - [Chaîne de tokens](#chaîne-de-tokens)
  - [Détails techniques de la chaîne](#détails-techniques-de-la-chaîne)
  - [Cycle de vie des tokens](#cycle-de-vie-des-tokens)
  - [Installation de Chromium](#installation-de-chromium)
- [Synchronisation du catalogue](#synchronisation-du-catalogue)
  - [Flux de synchronisation](#flux-de-synchronisation)
  - [Format games.map](#format-gamesmap)
- [Lancement d'un jeu xCloud](#lancement-dun-jeu-xcloud)
  - [Flux de lancement](#flux-de-lancement)
  - [Flags Chromium pour xCloud](#flags-chromium-pour-xcloud)
  - [Profil Chromium partagé](#profil-chromium-partagé)
- [Clavier virtuel](#clavier-virtuel)
  - [Injection et détection de la locale](#injection-et-détection-de-la-locale)
  - [Layouts disponibles](#layouts-disponibles)
  - [Design visuel](#design-visuel)
- [Environnement Steam Deck](#environnement-steam-deck)
  - [Variables d'environnement](#variables-denvironnement-injectées-par-clean_env)
  - [Détection XAUTHORITY](#détection-xauthority)
- [Gestion des cookies et logout](#gestion-des-cookies-et-logout)
  - [Logout bidirectionnel](#logout-bidirectionnel)
  - [Profil Chromium partagé](#profil-chromium-partagé-1)
  - [Lecture des cookies](#lecture-des-cookies-sans-bloquer-chromium)
- [Interface utilisateur](#interface-utilisateur-frontend)
  - [Bouton "Jouer sur le Cloud"](#bouton-jouer-sur-le-cloud)
  - [Connexion depuis le QAM](#connexion-depuis-le-qam)
- [Gestion des erreurs](#gestion-des-erreurs)
- [Prérequis et dépendances](#prérequis-et-dépendances)
- [Configuration](#configuration)
- [Internationalisation](#internationalisation)
- [Sécurité](#sécurité)
- [Limitations connues](#limitations-connues)

---

## Vue d'ensemble

L'intégration Microsoft permet aux utilisateurs Steam Deck de **jouer à plus de 500 jeux Xbox Cloud Gaming (xCloud)** directement depuis leur bibliothèque Steam, via le plugin Unifideck. Les jeux sont streamés depuis les serveurs Microsoft — aucune installation locale n'est nécessaire.

Cette fonctionnalité transforme le Steam Deck en console Xbox portable en intégrant de façon transparente les jeux Game Pass dans l'interface Steam.

### Ce que ça apporte au plugin

- **Accès à ~500+ jeux** du catalogue xCloud sans téléchargement
- **Authentification unifiée** : connexion Microsoft depuis le QAM (Quick Access Menu) de Steam
- **Lancement natif** : les jeux xCloud apparaissent dans la bibliothèque Steam comme des raccourcis, avec artwork et bouton "Jouer sur le Cloud"
- **Clavier virtuel** AZERTY/QWERTY intégré pour l'écran d'authentification tactile
- **Synchronisation bidirectionnelle** du logout entre le plugin et xbox.com

---

## Architecture

### Fichiers et responsabilités

L'intégration Microsoft est découpée en modules spécialisés à responsabilité unique. Le connecteur principal orchestre l'authentification et la synchronisation, tandis que la gestion du navigateur, les appels HTTP, l'interception CDP et le clavier virtuel sont isolés dans leurs propres fichiers. Cette séparation facilite le débogage, les tests unitaires et l'évolution indépendante de chaque composant.

| Fichier | Rôle |
|---------|------|
| `stores/microsoft.py` | Connecteur principal : auth, tokens, catalogue |
| `stores/microsoft_chromium.py` | Gestion du navigateur Chromium |
| `stores/microsoft_auth.py` | Helpers HTTP, chaîne XBL/XSTS |
| `stores/microsoft_cdp.py` | Interception OAuth via CDP |
| `utils/virtual_keyboard.py` | Clavier virtuel injecté via CDP |
| `bin/unifideck-launcher` | Lancement xCloud |
| `src/components/PlayButtonOverride.tsx` | Bouton "Jouer sur le Cloud" |
| `src/components/ChromiumInstallModal.tsx` | Modal d'installation Chromium |
| `src/components/StoreConnections.tsx` | Panneau de connexion Microsoft |

### Diagramme des modules

![Architecture des modules](../assets/Microsoft/architecture.svg)

### Parcours utilisateur (machine d'états)

Le diagramme suivant représente l'ensemble des états possibles de l'interface depuis le point de vue de l'utilisateur. Chaque transition correspond à une action utilisateur ou un événement système (succès, échec, timeout). Les chemins d'erreur ramènent systématiquement à l'état initial.

![Machine d'états frontend](../assets/Microsoft/frontend-states.svg)

---

## Flux d'authentification

L'authentification utilise **Microsoft OAuth 2.0** avec interception du code d'autorisation via le **Chrome DevTools Protocol (CDP)**. Chromium est lancé en dehors de Steam pour que les cookies persistent entre les sessions.

### Séquence complète

![Séquence d'authentification](../assets/Microsoft/auth-sequence.svg)

### Chaîne de tokens

Après l'obtention du code OAuth, le backend construit une chaîne de tokens pour accéder aux APIs Xbox :

![Chaîne de tokens XBL/XSTS](../assets/Microsoft/token-chain.svg)

### Détails techniques de la chaîne

Le `RpsTicket` prefix (`d=` vs `t=`) dépend du format de token :
- `t=` est correct pour les tokens JWT OAuth2
- `d=` est pour les tickets compacts legacy

`x-xbl-contract-version: "2"` est requis avec le prefix `t=` pour que le flux XBL réussisse.

### Cycle de vie des tokens

Les tokens Microsoft ont une durée de vie limitée (~1 heure pour l'access token). Le plugin gère automatiquement leur renouvellement de façon transparente pour l'utilisateur. À chaque appel API (synchronisation, vérification de statut), `_ensure_fresh_ms_token()` vérifie l'âge du token : s'il approche de l'expiration, un rafraîchissement est déclenché via le `refresh_token` persisté sur disque. Si le refresh échoue (token révoqué, compte modifié), le plugin effectue un logout automatique et demande une nouvelle authentification.

![Cycle de vie des tokens](../assets/Microsoft/token-lifecycle.svg)

### Installation de Chromium

Lorsque Chromium n'est pas détecté sur le système, le backend retourne `needs_chromium: true` au frontend. Le `ChromiumInstallModal` propose alors à l'utilisateur d'installer Chromium automatiquement via flatpak. L'installation terminée, l'auth est relancée sans intervention supplémentaire.

![Flux d'installation Chromium](../assets/Microsoft/chromium-install.svg)

---

## Synchronisation du catalogue

La synchronisation récupère la liste complète des jeux xCloud disponibles et les ajoute à la bibliothèque Steam.

### Flux de synchronisation

![Flux de synchronisation](../assets/Microsoft/sync-flow.svg)

### Format games.map

```
microsoft:{productId}|xcloud|{url_complet}
```

Exemple :
```
microsoft:9NPDN9R45JX4|xcloud|https://www.xbox.com/play/launch/9NPDN9R45JX4
```

Le launcher lit cette entrée pour déterminer qu'il s'agit d'un jeu xCloud et ouvrir Chromium.

---

## Lancement d'un jeu xCloud

### Flux de lancement

![Flux de lancement de jeu](../assets/Microsoft/game-launch.svg)

### Flags Chromium pour xCloud

| Flag | Rôle |
|------|------|
| `--app=URL` | Mode application : pas de barre d'adresse ni d'onglets |
| `--start-fullscreen` | Plein écran (pas de bordure de fenêtre) |
| `--user-data-dir=chromium-auth/` | Profil partagé avec l'auth → cookies SSO |
| `--enable-gamepad-button-axis-events` | Support manette Steam Deck |
| `--enable-features=WebGamepad` | API Gamepad web activée |
| `--autoplay-policy=no-user-gesture-required` | Lecture vidéo automatique |
| `--disable-dev-shm-usage` | Compatibilité mémoire partagée |
| `--password-store=basic` | Évite les popups KWallet/GNOME Keyring |

### Profil Chromium partagé

Le même répertoire `~/.local/share/unifideck/chromium-auth/` est utilisé pour :

1. **L'authentification** — les cookies Microsoft sont créés ici
2. **Le lancement de jeux** — Chromium réutilise ces cookies pour le SSO xbox.com

Cela évite une double authentification.

---

## Clavier virtuel

Steam Deck n'a pas de clavier physique. Le clavier overlay de Steam n'est pas disponible car Chromium est lancé en dehors de Steam. La solution : un **clavier virtuel injecté via CDP**.

### Injection et détection de la locale

![Injection du clavier virtuel](../assets/Microsoft/keyboard-injection.svg)

### Layouts disponibles

Deux layouts sont supportés, sélectionnés automatiquement en fonction de la locale :
- **AZERTY** pour les locales `fr-*`
- **QWERTY** pour toutes les autres locales

### Design visuel

Le clavier utilise une esthétique proche de Steam :

- Fond translucide avec `backdrop-filter: blur(20px)`
- Touches avec dégradé et ombre interne subtile
- Animation slide-up au focus (`transform: translateY`)
- Feedback tactile : scale 0.94 au press
- Icônes SVG pour Shift, Backspace, Enter
- Touche Enter bleue (accent couleur Steam)
- Badge AZERTY/QWERTY en bas à droite

---

## Environnement Steam Deck

Le plugin tourne dans **PluginLoader** (service systemd) qui n'a pas d'environnement graphique. Lancer Chromium nécessite d'injecter les variables d'environnement manquantes.

### Variables d'environnement injectées par `clean_env()`

| Variable | Valeur | Raison |
|----------|--------|--------|
| `DISPLAY` | `:0` | Session X11 |
| `XDG_RUNTIME_DIR` | `/run/user/1000` | Socket bus |
| `DBUS_SESSION_BUS_ADDRESS` | `unix:path=/run/user/1000/bus` | D-Bus |
| `XAUTHORITY` | `/run/user/1000/xauth_*` (glob) | Auth X11 (nom aléatoire SteamOS) |
| `GTK_MODULES` | `""` | Supprime warnings canberra |

### Détection XAUTHORITY

SteamOS utilise un fichier xauth à nom aléatoire. La détection se fait par glob :

```python
xauth_files = glob.glob(f"/run/user/{uid}/xauth_*")
# → ["/run/user/1000/xauth_TVSUbt"]
```

---

## Gestion des cookies et logout

La connexion et la déconnexion au compte Microsoft s'effectuent **une seule fois**, depuis l'interface utilisateur du plugin Unifideck (QAM → Microsoft → Connecter). Une fois authentifié, l'utilisateur n'a plus besoin de se reconnecter — les cookies de session persistent dans le profil Chromium partagé et sont réutilisés automatiquement à chaque lancement de jeu. La déconnexion se fait également depuis le plugin, et se propage aux cookies du navigateur.

### Logout bidirectionnel

Le plugin maintient la cohérence entre son propre état d'authentification (tokens OAuth stockés sur disque) et l'état de la session dans le navigateur Chromium (cookies xbox.com). Si l'utilisateur se déconnecte depuis l'un ou l'autre côté, les deux sont synchronisés automatiquement : un logout depuis le plugin efface les cookies Chromium, et une session expirée dans le navigateur déclenche un auto-logout côté plugin.

![Synchronisation du logout](../assets/Microsoft/logout-sync.svg)

### Profil Chromium partagé

Le répertoire `~/.local/share/unifideck/chromium-auth/` est le point central de la persistance de session. Il stocke les cookies Microsoft créés lors de l'authentification et les met à disposition du launcher pour le SSO xbox.com au moment du streaming. Ce profil est également consulté par le plugin pour détecter si l'utilisateur s'est déconnecté depuis la page Game Pass, et nettoyé lors d'un logout explicite.

![Profil Chromium partagé](../assets/Microsoft/chromium-profile.svg)

### Lecture des cookies (sans bloquer Chromium)

Chromium verrouille sa base SQLite. La lecture se fait via une copie temporaire :

```python
shutil.copy2(cookie_db, tmp_path)  # copie atomique
conn = sqlite3.connect(tmp_path)    # lecture sans lock
cursor = conn.execute(
    "SELECT COUNT(*) FROM cookies WHERE host_key LIKE '%xbox.com%'"
)
```

---

## Interface utilisateur (Frontend)

### Bouton "Jouer sur le Cloud"

Quand un jeu possède le tag `store_tags: ["xcloud"]`, le `PlayButtonOverride` affiche un bouton spécial :

| État | Affichage |
|------|-----------|
| Connecté | **▶ Play on Cloud** (bleu, cliquable) |
| Non connecté | **Sign in to play** (grisé, `opacity: 0.4`, `disabled`) |

Le clic déclenche `SteamClient.Apps.RunGame()` qui lance `unifideck-launcher` avec `LaunchOptions: microsoft:{productId}`.

### Connexion depuis le QAM

Le panneau `StoreConnections` dans le Quick Access Menu de Steam présente trois états distincts. L'interface s'adapte en temps réel à l'état de connexion, vérifié périodiquement par le frontend via `check_store_status`.

![États du panneau QAM](../assets/Microsoft/qam-states.svg)

---

## Gestion des erreurs

Chaque point de défaillance est couvert par un mécanisme de détection et de récupération. Le plugin ne reste jamais dans un état bloqué : les erreurs ramènent l'utilisateur à un état stable (QAM avec bouton "Connecter") depuis lequel il peut retenter l'opération.

![Gestion des erreurs](../assets/Microsoft/error-handling.svg)

---

## Prérequis et dépendances

L'intégration Microsoft nécessite les éléments suivants, vérifiés automatiquement par le plugin :

| Prérequis | Vérification | Fallback |
|-----------|-------------|----------|
| **Chromium** (flatpak ou natif) | `find_cmd()` teste --user et --system | `ChromiumInstallModal` proposé |
| **websockets** (Python) | `import websockets` dans `inject_virtual_keyboard` | Clavier non injecté (non bloquant) |
| **Connexion Internet** | Implicite (appels API Microsoft) | Erreurs HTTP loguées |
| **Abonnement Game Pass** | Vérifié par xbox.com au lancement | Page "abonnez-vous" affichée |
| **flatpak** (pour l'installation) | `shutil.which("flatpak")` | Erreur `flatpakNotFound` |
| **Session X11** (DISPLAY) | `clean_env()` injecte `:0` | Chromium ne s'ouvre pas |

Le plugin est conçu pour fonctionner sans intervention manuelle : si un prérequis manque, l'interface guide l'utilisateur vers la résolution (installation Chromium, re-connexion).

---

## Configuration

Tous les endpoints et paramètres sont lus depuis `settings.json` (pas hardcodés) :

| Clé | Usage |
|-----|-------|
| `client_id` | ID application Microsoft OAuth |
| `auth_url` | Endpoint OAuth authorize |
| `token_url` | Endpoint OAuth token |
| `redirect_uri` | URI de redirection OAuth |
| `scope` | `Xboxlive.signin Xboxlive.offline_access` |
| `xbl_auth_url` | Endpoint XBL user token |
| `xsts_url` | Endpoint XSTS token |
| `product_url` | Display catalog API |
| `gamepass_catalog_url` | Catalogue Game Pass |
| `xcloud_catalog_id` | ID du catalogue xCloud |
| `token_file` | Chemin du fichier de tokens |

---

## Internationalisation

### OAuth

Le paramètre `ui_locales` est ajouté à l'URL OAuth pour que la page Microsoft s'affiche dans la langue de l'utilisateur :

```
/authorize?...&ui_locales=fr-FR
```

### Clavier virtuel

Le layout (AZERTY/QWERTY) est sélectionné en fonction de la locale Unifideck :
- `fr-*` → AZERTY
- Tout autre → QWERTY

### Locales frontend

14 langues supportées : `en-US`, `fr-FR`, `de-DE`, `es-ES`, `it-IT`, `pt-BR`, `ru-RU`, `ja-JP`, `ko-KR`, `zh-CN`, `nl-NL`, `pl-PL`, `tr-TR`, `uk-UA`

Clés principales : `playOnCloud`, `signInRequired`, `xcloudStreaming`, `chromiumRequired`, `chromiumInstalled`

---

## Sécurité

- Les tokens OAuth sont stockés localement dans un fichier (chemin configurable via `settings.json`)
- Le `refresh_token` est le seul secret persisté ; l'`access_token` expire après ~1h
- Les cookies Chromium sont dans un profil dédié (`chromium-auth/`)
- Le `client_id` est public (application Microsoft enregistrée)
- Aucun secret serveur n'est nécessaire (flux OAuth public client)
- `LD_LIBRARY_PATH` et `LD_PRELOAD` sont nettoyés pour éviter les injections via PluginLoader

---

## Limitations connues

1. **Streaming uniquement** — aucun jeu n'est téléchargé/installé localement
2. **Abonnement Game Pass requis** — vérifié côté serveur (xbox.com) au lancement
3. **Nécessite Chromium** — installé via flatpak si absent
4. **Qualité réseau** — le streaming dépend de la connexion Internet
5. **Pas de support manette natif Steam Input** — le gamepad passe via l'API WebGamepad de Chromium
